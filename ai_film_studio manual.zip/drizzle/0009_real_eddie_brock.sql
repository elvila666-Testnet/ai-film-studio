ALTER TABLE `brands` ADD `description` text;--> statement-breakpoint
ALTER TABLE `brands` ADD `targetCustomer` text;--> statement-breakpoint
ALTER TABLE `brands` ADD `aesthetic` text;--> statement-breakpoint
ALTER TABLE `brands` ADD `mission` text;--> statement-breakpoint
ALTER TABLE `brands` ADD `coreMessaging` text;